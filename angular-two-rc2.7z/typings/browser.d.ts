/// <reference path="browser/ambient/core-js/index.d.ts" />
/// <reference path="browser/ambient/jasmine/index.d.ts" />
/// <reference path="browser/ambient/node/index.d.ts" />
