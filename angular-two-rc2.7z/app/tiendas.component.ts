import { Component } from '@angular/core';
@Component({
  selector: 'tiendas-tag',
  template: `
    <h2>Tiendas</h2>
    <p>Componente de tiendas</p>`
})
export class TiendasComponent { }