import { Component } from '@angular/core';
import { ROUTER_DIRECTIVES } from '@angular/router';

@Component({
  selector: 'my-app',
  template: `
    <h1>RUTAS EN ANGULAR 2</h1>
    <nav>
      <a [routerLink]="['/coches']">Coches</a>
      <a [routerLink]="['/tiendas']">Tiendas</a>
    </nav>
    <router-outlet></router-outlet>
  `,
  directives: [ROUTER_DIRECTIVES]
})

export class AppComponent { }