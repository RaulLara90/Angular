import { provideRouter, RouterConfig } from '@angular/router';
import { CochesComponent }  from './coches.component';
import { TiendasComponent }    from './tiendas.component';

export const routes: RouterConfig = [
  {
    path: '',
    redirectTo: '/tiendas',
    terminal: true
  },
  { path: 'coches', component: CochesComponent },
  { path: 'tiendas', component: TiendasComponent }
];
export const APP_ROUTER_PROVIDERS = [
  provideRouter(routes);
];