"use strict";
var router_1 = require('@angular/router');
var coches_component_1 = require('./coches.component');
var tiendas_component_1 = require('./tiendas.component');
exports.routes = [
    {
        path: '',
        redirectTo: '/tiendas',
        terminal: true
    },
    { path: 'coches', component: coches_component_1.CochesComponent },
    { path: 'tiendas', component: tiendas_component_1.TiendasComponent }
];
exports.APP_ROUTER_PROVIDERS = [
    router_1.provideRouter(exports.routes)];
;
//# sourceMappingURL=app.routes.js.map