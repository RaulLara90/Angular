import { Component } from '@angular/core';
@Component({
  selector: 'coches-tag',
  template: `
    <h2>COCHES</h2>
    <p>Componente de coches</p>`
})
export class CochesComponent { }