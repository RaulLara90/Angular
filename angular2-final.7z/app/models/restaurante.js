"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Restaurante = /** @class */ (function () {
    function Restaurante(id, nombre, direccion, descripcion, imagen, precio) {
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
        this.descripcion = descripcion;
        this.imagen = imagen;
        this.precio = precio;
    }
    return Restaurante;
}());
exports.Restaurante = Restaurante;
//# sourceMappingURL=restaurante.js.map