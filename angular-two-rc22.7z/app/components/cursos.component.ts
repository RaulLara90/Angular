import {Component} from "@angular/core";
import {Router, ActivatedRoute, ROUTER_DIRECTIVES} from "@angular/router";

@Component({
	selector: 'cursos-tag',
	template: `
		<p>
			<button (click)="redirect()">Redirigir al curso destacado</button>
		</p>
		<h2>Listado de cursos con un ID</h2>
		<ul>
			<li *ngFor="let curso of cursos">
				<a [routerLink]="['/curso',curso.id]">{{curso.titulo}}</a>
			</li>
		</ul>
		<h2>Listado de cursos con un ID y un TITULO</h2>
		<ul>
			<li *ngFor="let curso of cursos">
				<a [routerLink]="['/curso',curso.id,curso.titulo]">{{curso.titulo}}</a>
			</li>
		</ul>
	`,
	directives: [ROUTER_DIRECTIVES]
})

export class CursosComponent{
	public cursos:Array<any>;

	constructor(
		private route:ActivatedRoute,
		private router : Router
	){
		this.cursos=[
			{"id":1, "titulo":"Curso de Symfony 3"},
			{"id":2, "titulo":"Curso de Zend Framework 2"},
			{"id":3, "titulo":"Aprende PHP con 36 ejercicios prácticos"},
			{"id":4, "titulo":"Curso de Angular 2"}
		];
	}

	redirect(){
		let curso = this.cursos[0];
		this.router.navigate(['/curso',curso.id, curso.titulo]);
	}
}