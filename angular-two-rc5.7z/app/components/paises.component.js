"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var paises_service_1 = require("../services/paises.service");
var PaisesComponent = (function () {
    function PaisesComponent(_paisesServie) {
        var _this = this;
        this._paisesServie = _paisesServie;
        this._paisesServie.getPosts().subscribe(function (result) {
            _this.posts = result;
            if (_this.posts.length >= 1) {
                console.log(_this.posts);
            }
        }, function (error) {
            console.log(error);
        });
    }
    PaisesComponent = __decorate([
        core_1.Component({
            selector: 'paises',
            template: "\n\t\t<h2>Paises</h2>\n\t\t<ul>\n\t\t\t<li>Espa\u00F1a</li>\n\t\t\t<li>Mexico</li>\n\t\t\t<li>Colombia</li>\n\t\t</ul>\n\n\t\t<h2>Listado de posts</h2>\n\t\t<ol *ngIf=\"posts\">\n\t\t\t<li *ngFor=\"let post of posts\">{{post.id}} - {{post.title}}</li>\n\t\t</ol>\n\t",
            providers: [paises_service_1.PaisesService]
        }), 
        __metadata('design:paramtypes', [paises_service_1.PaisesService])
    ], PaisesComponent);
    return PaisesComponent;
}());
exports.PaisesComponent = PaisesComponent;
;
//# sourceMappingURL=paises.component.js.map